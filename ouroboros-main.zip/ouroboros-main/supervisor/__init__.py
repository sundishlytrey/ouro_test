"""Ouroboros Supervisor package — decomposed from monolithic colab_launcher.py."""
